import {
  BrowserPerformanceMeasurement
} from "./chunk-UCFCVG4N.js";
import "./chunk-35ENWJA4.js";
export {
  BrowserPerformanceMeasurement
};
