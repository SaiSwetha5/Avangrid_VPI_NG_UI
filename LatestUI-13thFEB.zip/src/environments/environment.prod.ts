export const environment = {
  production: true,
  apiBaseUrl: 'https://spring-boot-v1-final.onrender.com/api/v1'
};