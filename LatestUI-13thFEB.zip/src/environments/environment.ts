export const environment = {
  production: false,
  apiBaseUrl: 'https://spring-boot-v1-final.onrender.com/api/v1',
 };