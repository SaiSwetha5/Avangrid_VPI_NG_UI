// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html

//const puppeteer = require('puppeteer');

//process.env.CHROME_BIN = puppeteer.executablePath();

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma'),
      require('karma-junit-reporter')
    ],
    singleRun: true,
    client: {
      jasmine: {
        // you can add configuration options for Jasmine here
        // the possible options are listed at https://jasmine.github.io/api/edge/Configuration.html
        // for example, you can disable the random execution with `random: false`
        // or set a specific seed with `seed: 4321`
        random: false
      },
    },
    jasmineHtmlReporter: {
      suppressAll: true // removes the duplicated traces
    },
    coverageReporter: {
      dir: require('path').join(__dirname, './coverage'),
      subdir: '.',
      reporters: [
        { type: 'html' },
        { type: 'text-summary' },
        { type: 'lcovonly', subdir: '.' } 
      ]
    },
    junitReporter: {
      outputDir: 'reports',
      outputFile: 'junit_report.xml',
      useBrowserName: false
    },
    reporters: ['progress', 'kjhtml', 'junit', 'coverage'],
    browsers: ['ChromeHeadlessNoSandbox'],
    customLaunchers: {
      ChromeHeadlessNoSandbox: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox', '--disable-gpu']
      }
    },
    restartOnFileChange: false,

    singleRun: true, // Ensures Karma exits after running tests
    autoWatch: false, // Prevents Karma from waiting for file changes
    
    // Timeout settings to prevent premature disconnections
    browserDisconnectTimeout: 10000,  // Increase browser timeout
    browserNoActivityTimeout: 60000,  // Increase idle timeout
    captureTimeout: 90000, // Prevent premature disconnects
    concurrency: 1 // Run one test at a time to reduce crashes
  });
};
